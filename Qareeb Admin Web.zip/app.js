// app.js

require("dotenv").config();
const express = require("express");
const app = express();
const port = process.env.PORT || 3000;
const {connection} = require("./middleware/db"); // Assuming this is now safe
const bodyParser = require("body-parser");
const ejs = require("ejs");
const path = require("path");
const cookieParser = require("cookie-parser"); 
const flash = require("connect-flash");
const session = require("express-session");
const { publicsocket } = require("./public/publicsocket");
const vhost = require("vhost");

// --- Define separate Express applications for your domains ---
const webApp = express();
const mobileApiApp = express();
const adminApp = express(); // A new app for the admin panel

// --- A function to apply common middleware to all apps ---
const applyCommonMiddleware = (expressApp) => {
    expressApp.use(session({
        secret: 'keyboard cat',
        resave: false,
        saveUninitialized: true,
        cookie: {maxAge: 1000 * 60 }
    }));
    expressApp.use(flash());
    expressApp.use(bodyParser.urlencoded({extended : false}));
    expressApp.use(bodyParser.json());
    expressApp.use(express.json());
    expressApp.use(cookieParser());
    expressApp.use(function (req, res, next) {
        res.locals.success = req.flash("success");
        res.locals.errors = req.flash("errors");
        next();
    });
};

// --- Apply the common middleware to each application ---
applyCommonMiddleware(webApp);
applyCommonMiddleware(mobileApiApp);
applyCommonMiddleware(adminApp);


// --- Web Application Routes and Middleware ---
webApp.set('view engine', 'ejs');
webApp.set("views", path.join(__dirname, 'views'));
webApp.use(express.static(path.join(__dirname, 'public')));
webApp.use("/", require("./router/login"));
webApp.use("/", require("./router/index"));
webApp.use("/settings", require("./router/settings"));
webApp.use("/vehicle", require("./router/vehicle"));
webApp.use("/zone", require("./router/zone"));
webApp.use("/outstation", require("./router/outstation"));
webApp.use("/rental", require("./router/rental"));
webApp.use("/package", require("./router/package"));
webApp.use("/customer", require("./router/customer"));
webApp.use("/driver", require("./router/driver"));
webApp.use("/coupon", require("./router/coupon"));
webApp.use("/report", require("./router/report"));
webApp.use("/role", require("./router/role_permission"));
webApp.use("/rides", require("./router/ride"));

// --- Mobile API Application Routes ---
mobileApiApp.use("/customer", require("./route_mobile/customer_api"));
mobileApiApp.use("/driver", require("./route_mobile/driver_api"));
mobileApiApp.use("/chat", require("./route_mobile/chat"));
mobileApiApp.use("/payment", require("./route_mobile/payment"));

// --- Admin Application Routes (placeholder) ---
adminApp.get('/', (req, res) => {
    res.send('This is the Admin Panel');
});
// You would add your specific admin routes here, e.g.:
// adminApp.use("/dashboard", require("./router/admin_dashboard"));

// --- Main App Uses Vhost to Route to the Correct Mini-App ---
// For local development, use 'localhost', 'api.localhost', 'admin.localhost'
// For production, these would be 'your-main-domain.com', 'api.your-main-domain.com', etc.
app.use(vhost('localhost', webApp));
app.use(vhost('api.localhost', mobileApiApp));
app.use(vhost('admin.localhost', adminApp));

// --- Handle requests that do not match a subdomain ---
app.use((req, res) => {
    res.status(404).send('Not Found');
});

const http = require("http");
const httpServer = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(httpServer, {
    // Socket.IO options can go here if needed
});

publicsocket(io);

httpServer.listen(port, () => {
    console.log(`Server running on port ${port}`);
    console.log(`Main Web App: http://localhost:${port}`);
    console.log(`Mobile API:   http://api.localhost:${port}`);
    console.log(`Admin App:    http://admin.localhost:${port}`);
});